import React from 'react';
import Film from './Film';
function Films(props) {
const {movie=[]}=props;

  return (
    <div className='films'>
      {movie.length ? movie.map(mov=><Film mov={mov} key={mov.imdbID} />) : <h1> not found</h1>}
    </div>
  );
}

export default Films;