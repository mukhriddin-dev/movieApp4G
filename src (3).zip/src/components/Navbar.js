import React from 'react';

const Navbar = () => {
    return (
        <>
           
  <nav className="bg">
    <div class="nav-wrapper">
      <a href="#" class="brand-logo left brand">Movie app</a>
    
    </div>
  </nav>
    
        </>
    );
};


export default Navbar;