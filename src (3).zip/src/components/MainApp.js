
import React from 'react';
import Films from './Films';
import Search from './Search';

const MainApp = () => {
    return (
        <div className='main'>
                     <Search/>
            <Films/>
   
        </div>
    );
};


export default MainApp;
