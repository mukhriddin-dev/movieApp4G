import React from 'react';

function Navbar(props) {
  return (
    <div className='nav-menu'>
      MovieApp
    </div>
  );
}

export default Navbar;