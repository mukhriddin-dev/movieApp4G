import React from 'react';

function Loader(props) {
  return (
    <>
      <div class="progress">
      <div class="indeterminate"></div>
      </div>
        
    </>
  );
}

export default Loader;