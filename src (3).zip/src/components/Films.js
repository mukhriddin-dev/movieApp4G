import React, { Component } from 'react'
import Film from './Film'

export default class Films extends Component {
    state={
        movie:[]
    }


componentDidMount(){
    fetch(`http://www.omdbapi.com/?apikey=65e6b2ef&s=${txt}`)
    .then(response => response.json())
    .then(result=> this.setState({movie: result.Search}))
    .catch(err => console.log(err))
}



getFilms=(text)=>{

    fetch(`http://www.omdbapi.com/?apikey=65e6b2ef&s=tom ${text}`)
    .then(response => response.json())
    .then(result=> this.setState({movie: result.Search}))
    .catch(err => console.log(err))
}







    render() {
        return (
            <div className='films'>
              {this.state.movie.map(item=> <Film item= {item} key={item.imdbID}/>)}
            </div>
        )
    }
}
